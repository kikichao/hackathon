#!/bin/bash
yum install -y httpd
